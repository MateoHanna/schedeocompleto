# backend/database.py
import mysql.connector

def get_db_connection():
    connection = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Mateo2830",
    database="schedeo", 
    port=3306  # Cambia esto si tu MySQL está usando otro puerto
)

    return connection

