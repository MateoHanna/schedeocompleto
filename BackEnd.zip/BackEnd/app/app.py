# backend/app/app.py
from flask import Flask, request, jsonify,session, Blueprint
import json
from werkzeug.utils import secure_filename
import os
from flask_cors import CORS
from flask_session import Session
from ConexionDB.ConexionDB import get_db_connection
from functools import wraps
import jwt
from flask import Flask, request, jsonify, session, Blueprint, redirect
import datetime


app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
CORS(app, 
     supports_credentials=True,
     resources={
         r"/*": {
             "origins": [
                 "http://localhost:3000",  # Para desarrollo
                 "https://MateoHanna.github.io",  # Tu dominio de GitHub Pages
                 "https://6706-177-93-3-49.ngrok-free.app"  # URL de ngrok
             ],
             "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
             "allow_headers": ["Content-Type", "Authorization"]
         }
     })
# Clave secreta para JWT (deberías moverla a un archivo de configuración)
JWT_SECRET = 'tu_clave_secreta_muy_segura'

# Decorator para verificar el token
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # Permitir solicitudes OPTIONS sin token
        if request.method == 'OPTIONS':
            return jsonify({}), 200
            
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'message': 'Token faltante', 'loggedin': False}), 401
            
        try:
            # Asegurarse de manejar correctamente el formato "Bearer token"
            if ' ' in token:
                scheme, token = token.split(' ', 1)
                if scheme.lower() != 'bearer':
                    return jsonify({'message': 'Formato de token inválido', 'loggedin': False}), 401
            
            # Decodificar el token
            data = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            request.user = data
            return f(*args, **kwargs)
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token expirado', 'loggedin': False}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token inválido', 'loggedin': False}), 401
        except Exception as e:
            print(f"Error en token_required: {e}")
            return jsonify({'message': 'Error al procesar token', 'loggedin': False}), 401
            
    return decorated
# Funciones para registrar  --------------------------------------------------------------------------------

#Registrar Usuarios
@app.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        nombre = data.get('name')
        usuario = data.get('usuario') 
        correo = data.get('email')
        contrasena = data.get('password')

        if not nombre or not usuario or not correo or not contrasena:
            return jsonify({'message': 'Todos los campos son requeridos'}), 400

        # Validar longitud mínima de contraseña
        if len(contrasena) < 8:
            return jsonify({'message': 'La contraseña debe tener al menos 8 caracteres'}), 400

        # Validar formato de correo electrónico básico
        if '@' not in correo or '.' not in correo:
            return jsonify({'message': 'Formato de correo electrónico inválido'}), 400

        connection = get_db_connection()
        if not connection:
            return jsonify({'message': 'Error al conectar con la base de datos'}), 500
            
        cursor = connection.cursor()

        # Verificar si el usuario ya existe
        cursor.execute('SELECT * FROM persona WHERE usuario = %s OR correo = %s', (usuario, correo))
        if cursor.fetchone():
            cursor.close()
            connection.close()
            return jsonify({'message': 'El usuario o correo ya existe'}), 409

        try:
            # Remove the backticks and database name
            cursor.execute("INSERT INTO persona (nombre_completo, usuario, correo, contrasena) VALUES (%s, %s, %s, %s)", 
               (nombre, usuario, correo, contrasena))

            connection.commit()
            cursor.close()
            connection.close()

            return jsonify({'message': 'Usuario registrado exitosamente'}), 201

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error en la base de datos: {db_error}")
            return jsonify({'message': 'Error al insertar en la base de datos', 'error': str(db_error)}), 500

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

#Login --------------------------------------------------------------------------------

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('usuario')
        password = data.get('contrasena')

        if not username or not password:
            return jsonify({'message': 'Usuario y contraseña son requeridos'}), 400

        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute(
            'SELECT id_usuario, nombre_completo, usuario, correo FROM persona WHERE usuario = %s AND contrasena = %s',
            (username, password)
        )
        record = cursor.fetchone()

        if record:
            # Generar token JWT
            token = jwt.encode({
                'id_usuario': record[0],
                'nombre_completo': record[1],
                'usuario': record[2],
                'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1)
            }, JWT_SECRET, algorithm="HS256")

            cursor.close()
            connection.close()

            return jsonify({
                'message': 'Inicio de sesión exitoso',
                'usuario': {
                    'id_usuario': record[0],
                    'nombre_completo': record[1],
                    'usuario': record[2],
                    'correo': record[3]
                },
                'token': token
            }), 200
        else:
            cursor.close()
            connection.close()
            return jsonify({'message': 'Usuario o contraseña incorrectos'}), 401
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500


@app.route('/session', methods=['GET'])
@token_required
def session_info():
    try:
        # El usuario ya está verificado por el decorador token_required
        user_data = request.user  # Esto viene del decorador

        return jsonify({
            'message': 'Sesión activa',
            'usuario': {
                'id_usuario': user_data['id_usuario'],
                'nombre_completo': user_data['nombre_completo'],
                'usuario': user_data['usuario']
            },
            'loggedin': True
        }), 200
    except Exception as e:
        print(f"Error en session_info: {e}")
        return jsonify({'message': 'Error al verificar sesión', 'loggedin': False}), 401

# Logout --------------------------------------------------------------------------------

@app.route('/logout', methods=['POST'])
@token_required
def logout():
    try:
        # Con JWT no necesitamos limpiar la sesión, el cliente debe eliminar el token
        return jsonify({'message': 'Sesión cerrada exitosamente'}), 200
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error al cerrar sesión', 'error': str(e)}), 500

# Obtener información del usuario --------------------------------------------------------------------------------

@app.route('/obtener-info-usuario', methods=['GET'])
@token_required
def obtener_info_usuario():
    try:
        id_usuario = request.user['id_usuario']  # Obtenemos el ID del token
        
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute(
            'SELECT nombre_completo, usuario, correo FROM persona WHERE id_usuario = %s',
            (id_usuario,)
        )
        usuario = cursor.fetchone()

        cursor.close()
        connection.close()

        if usuario:
            return jsonify({
                'nombre_completo': usuario[0],
                'usuario': usuario[1],
                'correo': usuario[2]
            }), 200
        else:
            return jsonify({'message': 'Usuario no encontrado'}), 404

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Editar información del usuario --------------------------------------------------------------------------------

@app.route('/editar-usuario', methods=['PUT'])
@token_required
def editar_usuario():
    try:
        id_usuario = request.user['id_usuario']
        data = request.get_json()
        nuevo_nombre = data.get('nuevo_nombre')
        nuevo_usuario = data.get('nuevo_usuario')
        contrasena_actual = data.get('contrasena_actual')
        nueva_contrasena = data.get('nueva_contrasena')

        connection = get_db_connection()
        cursor = connection.cursor()

        # Verificar la contraseña actual
        cursor.execute(
            'SELECT contrasena FROM persona WHERE id_usuario = %s',
            (id_usuario,)
        )
        usuario = cursor.fetchone()

        if not usuario or usuario[0] != contrasena_actual:
            cursor.close()
            connection.close()
            return jsonify({'message': 'Contraseña actual incorrecta'}), 401

        try:
            if nueva_contrasena:
                cursor.execute("""
                    UPDATE persona 
                    SET nombre_completo = %s,
                        usuario = %s,
                        contrasena = %s
                    WHERE id_usuario = %s
                """, (nuevo_nombre, nuevo_usuario, nueva_contrasena, id_usuario))
            else:
                cursor.execute("""
                    UPDATE persona 
                    SET nombre_completo = %s,
                        usuario = %s
                    WHERE id_usuario = %s
                """, (nuevo_nombre, nuevo_usuario, id_usuario))

            connection.commit()
            cursor.close()
            connection.close()

            return jsonify({
                'message': 'Información actualizada exitosamente',
                'usuario': {
                    'nombre_completo': nuevo_nombre,
                    'usuario': nuevo_usuario
                }
            }), 200

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error en la base de datos: {db_error}")
            return jsonify({'message': 'Error al actualizar la información', 'error': str(db_error)}), 500

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Obtener tareas del usuario --------------------------------------------------------------------------------

@app.route('/obtener-tareas', methods=['GET'])
@token_required
def obtener_tareas():
    try:
        # Obtener el id_usuario del token JWT
        id_usuario = request.user['id_usuario']

        connection = get_db_connection()
        if not connection:
            return jsonify({'message': 'Error al conectar con la base de datos'}), 500

        cursor = connection.cursor()

        # Obtener las tareas del usuario
        cursor.execute("""
            SELECT id, nombre_tarea, descripcion, fecha_vencimiento, 
                   prioridad, completada, creado_en 
            FROM tareas 
            WHERE id_usuario = %s
            ORDER BY creado_en DESC
        """, (id_usuario,))
        
        tareas = cursor.fetchall()
        
        # Convertir los resultados a una lista de diccionarios
        tareas_lista = []
        for tarea in tareas:
            tareas_lista.append({
                'id': tarea[0],
                'nombre_tarea': tarea[1],
                'descripcion': tarea[2],
                'fecha_vencimiento': tarea[3].isoformat() if tarea[3] else None,
                'prioridad': tarea[4],
                'completada': bool(tarea[5]),
                'creado_en': tarea[6].isoformat() if tarea[6] else None
            })

        cursor.close()
        connection.close()

        return jsonify({
            'message': 'Tareas obtenidas exitosamente',
            'tareas': tareas_lista
        }), 200

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Crear tareas --------------------------------------------------------------------------------

@app.route('/crear-tarea', methods=['POST'])
@token_required
def crear_tarea():
    try:
        id_usuario = request.user['id_usuario']
        data = request.get_json()
        nombre_tarea = data.get('nombre_tarea')
        descripcion = data.get('descripcion')
        fecha_vencimiento = data.get('fecha_vencimiento')
        prioridad = data.get('prioridad', 'media')

        # Debug: Imprimir los valores recibidos
        print("Datos recibidos:", {
            "id_usuario": id_usuario,
            "nombre_tarea": nombre_tarea,
            "descripcion": descripcion,
            "fecha_vencimiento": fecha_vencimiento,
            "prioridad": prioridad
        })

        if not nombre_tarea:
            return jsonify({'message': 'El nombre de la tarea es requerido'}), 400

        if prioridad not in ['baja', 'media', 'alta']:
            return jsonify({'message': 'Prioridad inválida. Debe ser baja, media o alta'}), 400

        connection = get_db_connection()
        cursor = connection.cursor()

        try:
            # Insertar la tarea
            cursor.execute("""
                INSERT INTO tareas 
                (id_usuario, nombre_tarea, descripcion, fecha_vencimiento, prioridad, completada) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (
                id_usuario,
                nombre_tarea,
                descripcion,
                fecha_vencimiento if fecha_vencimiento else None,
                prioridad,
                0  # False en MySQL
            ))
            
            # Obtener el ID de la tarea recién creada
            tarea_id = cursor.lastrowid
            connection.commit()

            # Obtener la tarea recién creada
            cursor.execute("""
                SELECT id, id_usuario, nombre_tarea, descripcion, 
                       fecha_vencimiento, prioridad, completada, creado_en 
                FROM tareas WHERE id = %s
            """, (tarea_id,))
            
            nueva_tarea = cursor.fetchone()
            
            if nueva_tarea:
                resultado = {
                    'message': 'Tarea creada exitosamente',
                    'tarea': {
                        'id': nueva_tarea[0],
                        'id_usuario': nueva_tarea[1],
                        'nombre_tarea': nueva_tarea[2],
                        'descripcion': nueva_tarea[3],
                        'fecha_vencimiento': nueva_tarea[4].isoformat() if nueva_tarea[4] else None,
                        'prioridad': nueva_tarea[5],
                        'completada': bool(nueva_tarea[6]),
                        'creado_en': nueva_tarea[7].isoformat() if nueva_tarea[7] else None
                    }
                }
                cursor.close()
                connection.close()
                return jsonify(resultado), 201
            else:
                cursor.close()
                connection.close()
                return jsonify({'message': 'Error: No se pudo obtener la tarea creada'}), 500

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error específico en la base de datos: {str(db_error)}")
            return jsonify({
                'message': 'Error al crear la tarea', 
                'error': str(db_error),
                'sql_state': getattr(db_error, 'sqlstate', None)
            }), 500

    except Exception as e:
        print(f"Error general: {str(e)}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Editar tareas --------------------------------------------------------------------------------

@app.route('/editar-tarea/<int:tarea_id>', methods=['PUT'])
@token_required
def editar_tarea(tarea_id):
    try:
        # Obtener el id_usuario del token JWT
        id_usuario = request.user['id_usuario']

        data = request.get_json()
        nuevo_nombre = data.get('nombre_tarea')
        nueva_descripcion = data.get('descripcion')
        nueva_fecha_vencimiento = data.get('fecha_vencimiento')
        nueva_prioridad = data.get('prioridad')
        completada = data.get('completada')

        connection = get_db_connection()
        cursor = connection.cursor()

        # Verificar que la tarea existe y pertenece al usuario
        cursor.execute('SELECT id_usuario FROM tareas WHERE id = %s', (tarea_id,))
        tarea = cursor.fetchone()

        if not tarea:
            cursor.close()
            connection.close()
            return jsonify({'message': 'Tarea no encontrada'}), 404

        if tarea[0] != id_usuario:
            cursor.close()
            connection.close()
            return jsonify({'message': 'No tienes permiso para editar esta tarea'}), 403

        try:
            # Actualizar la tarea
            cursor.execute("""
                UPDATE tareas 
                SET nombre_tarea = %s,
                    descripcion = %s,
                    fecha_vencimiento = %s,
                    prioridad = %s,
                    completada = %s
                WHERE id = %s
            """, (
                nuevo_nombre,
                nueva_descripcion if nueva_descripcion else None,
                nueva_fecha_vencimiento if nueva_fecha_vencimiento else None,
                nueva_prioridad,
                1 if completada else 0,  # Convertir booleano a 0/1 para MySQL
                tarea_id
            ))

            connection.commit()

            # Obtener la tarea actualizada
            cursor.execute("""
                SELECT id, id_usuario, nombre_tarea, descripcion, 
                       fecha_vencimiento, prioridad, completada, creado_en 
                FROM tareas WHERE id = %s
            """, (tarea_id,))
            
            tarea_actualizada = cursor.fetchone()

            cursor.close()
            connection.close()

            return jsonify({
                'message': 'Tarea actualizada exitosamente',
                'tarea': {
                    'id': tarea_actualizada[0],
                    'id_usuario': tarea_actualizada[1],
                    'nombre_tarea': tarea_actualizada[2],
                    'descripcion': tarea_actualizada[3],
                    'fecha_vencimiento': tarea_actualizada[4].isoformat() if tarea_actualizada[4] else None,
                    'prioridad': tarea_actualizada[5],
                    'completada': bool(tarea_actualizada[6]),
                    'creado_en': tarea_actualizada[7].isoformat() if tarea_actualizada[7] else None
                }
            }), 200

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error en la base de datos: {db_error}")
            return jsonify({'message': 'Error al actualizar la tarea', 'error': str(db_error)}), 500

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Eliminar tareas --------------------------------------------------------------------------------

@app.route('/eliminar-tarea/<int:tarea_id>', methods=['DELETE', 'OPTIONS'])
@token_required
def eliminar_tarea(tarea_id):
    try:
        id_usuario = request.user['id_usuario']
        
        connection = get_db_connection()
        cursor = connection.cursor()

        # Verificar que la tarea existe y pertenece al usuario
        cursor.execute('SELECT * FROM tareas WHERE id = %s AND id_usuario = %s', (tarea_id, id_usuario))
        tarea = cursor.fetchone()

        if not tarea:
            cursor.close()
            connection.close()
            return jsonify({'message': 'Tarea no encontrada o sin permiso para eliminarla'}), 404

        try:
            # Insertar la tarea en tareas_eliminadas manteniendo el mismo ID
            cursor.execute("""
                INSERT INTO tareas_eliminadas 
                (id, id_usuario, nombre_tarea, descripcion, fecha_vencimiento, 
                prioridad, completada, creado_en)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (tarea[0], tarea[1], tarea[2], tarea[3], tarea[4], tarea[5], tarea[6], tarea[7]))

            # Eliminar la tarea de la tabla original
            cursor.execute('DELETE FROM tareas WHERE id = %s', (tarea_id,))
            connection.commit()

            cursor.close()
            connection.close()

            return jsonify({
                'message': 'Tarea movida a papelera exitosamente',
                'tarea_id': tarea_id
            }), 200

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error en la base de datos: {db_error}")
            return jsonify({'message': 'Error al mover la tarea a papelera', 'error': str(db_error)}), 500

    except Exception as e:
        print(f"Error al mover tarea a papelera: {str(e)}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Obtener tareas eliminadas --------------------------------------------------------------------------------

@app.route('/obtener-tareas-eliminadas', methods=['GET'])
@token_required
def obtener_tareas_eliminadas():
    try:
        id_usuario = request.user['id_usuario']
        
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            SELECT id, nombre_tarea, descripcion, fecha_vencimiento,
                   prioridad, completada, creado_en
            FROM tareas_eliminadas 
            WHERE id_usuario = %s
            ORDER BY creado_en DESC
        """, (id_usuario,))
        
        tareas = cursor.fetchall()
        
        tareas_lista = []
        for tarea in tareas:
            tareas_lista.append({
                'id': tarea[0],
                'nombre_tarea': tarea[1],
                'descripcion': tarea[2],
                'fecha_vencimiento': tarea[3].isoformat() if tarea[3] else None,
                'prioridad': tarea[4],
                'completada': bool(tarea[5]),
                'creado_en': tarea[6].isoformat() if tarea[6] else None
            })

        cursor.close()
        connection.close()

        return jsonify({
            'message': 'Tareas eliminadas obtenidas exitosamente',
            'tareas_eliminadas': tareas_lista
        }), 200

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Error al obtener tareas eliminadas', 'error': str(e)}), 500

# Restaurar tarea eliminada --------------------------------------------------------------------------------

@app.route('/restaurar-tarea/<int:tarea_id>', methods=['POST'])
@token_required
def restaurar_tarea(tarea_id):
    try:
        id_usuario = request.user['id_usuario']
        
        connection = get_db_connection()
        cursor = connection.cursor()

        # Obtener la tarea eliminada
        cursor.execute("""
            SELECT id, id_usuario, nombre_tarea, descripcion, 
                   fecha_vencimiento, prioridad, completada, creado_en
            FROM tareas_eliminadas 
            WHERE id = %s AND id_usuario = %s
        """, (tarea_id, id_usuario))
        
        tarea = cursor.fetchone()

        if not tarea:
            cursor.close()
            connection.close()
            return jsonify({'message': 'Tarea eliminada no encontrada'}), 404

        try:
            # Restaurar la tarea a la tabla original manteniendo el mismo ID
            cursor.execute("""
                INSERT INTO tareas 
                (id, id_usuario, nombre_tarea, descripcion, fecha_vencimiento, 
                prioridad, completada, creado_en)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, tarea)

            # Eliminar la tarea de tareas_eliminadas
            cursor.execute('DELETE FROM tareas_eliminadas WHERE id = %s', (tarea_id,))
            
            connection.commit()
            cursor.close()
            connection.close()

            return jsonify({
                'message': 'Tarea restaurada exitosamente',
                'tarea_id': tarea_id
            }), 200

        except Exception as db_error:
            connection.rollback()
            cursor.close()
            connection.close()
            print(f"Error en la base de datos: {db_error}")
            return jsonify({'message': 'Error al restaurar la tarea', 'error': str(db_error)}), 500

    except Exception as e:
        print(f"Error al restaurar tarea: {str(e)}")
        return jsonify({'message': 'Error interno del servidor', 'error': str(e)}), 500

# Eliminar tarea permanentemente --------------------------------------------------------------------------------

@app.route('/eliminar-permanente/<int:tarea_id>', methods=['DELETE'])
@token_required
def eliminar_permanente(tarea_id):
    try:
        id_usuario = request.user['id_usuario']
        
        connection = get_db_connection()
        cursor = connection.cursor()

        # Verificar que la tarea existe y pertenece al usuario
        cursor.execute('SELECT id FROM tareas_eliminadas WHERE id = %s AND id_usuario = %s', (tarea_id, id_usuario))
        if not cursor.fetchone():
            cursor.close()
            connection.close()
            return jsonify({'message': 'Tarea no encontrada o sin permiso para eliminarla'}), 404

        # Eliminar la tarea permanentemente
        cursor.execute('DELETE FROM tareas_eliminadas WHERE id = %s', (tarea_id,))
        connection.commit()

        cursor.close()
        connection.close()

        return jsonify({
            'message': 'Tarea eliminada permanentemente',
            'tarea_id': tarea_id
        }), 200

    except Exception as e:
        print(f"Error al eliminar permanentemente: {str(e)}")
        if 'connection' in locals():
            connection.rollback()
            cursor.close()
            connection.close()
        return jsonify({'message': 'Error al eliminar la tarea permanentemente', 'error': str(e)}), 500
