/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    // Archivos HTML
    'C:/Users/mateo/Documents/Schedeo/FrontEnd/Pantallashtml/*.html', 

    // Archivos JSX y JS
    'C:/Users/mateo/Documents/Schedeo/schedeo/src/**/*.{js,jsx}',

    // Otros archivos relevantes si los tienes
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
